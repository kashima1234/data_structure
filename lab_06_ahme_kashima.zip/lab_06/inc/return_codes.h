#ifndef RETURN_CODES_H
#define RETURN_CODES_H

#define OK 0 
#define FOPEN_ERROR 1
#define DATA_ERROR 2

#endif // RETURN_CODES_H