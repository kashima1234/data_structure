#ifndef _MAIN_H_
#define _MAIN_H_

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

#include "data_struct.h"
#include "linked_list_stack.h"
#include "arr_stack.h"
#include "parenthses.h"
#include "compare.h"

#endif //_MAIN_H_