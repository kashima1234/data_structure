#include "defines.h"
#include "process.h"

int main(void)
{
    int rc = 0;

    rc = process();
    
    return rc;
}
