#ifndef __GEN_DATA_H__
#define __GEN_DATA_H__

#include "defines.h"

void gen_data_file(const char *const file_name, const int count_data);

#endif
