#ifndef __TIMING_H__
#define __TIMING_H__

#include "defines.h"

long double microseconds_now(void);

#endif
