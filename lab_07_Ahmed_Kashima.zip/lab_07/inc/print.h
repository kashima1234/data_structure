#ifndef __PRINT_H__
#define __PRINT_H__

#include "defines.h"

void print_menu(void);

void print_choice_hash_func(void);

#endif
