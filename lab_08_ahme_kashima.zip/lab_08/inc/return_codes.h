#ifndef RETURN_CODES_H
#define RETURN_CODES_H

#define OK 0 
#define DATA_ERROR 1
#define FOPEN_ERROR 2
#define ALLOCATE_ERROR 3

#endif // RETURN_CODES_H