#ifndef _PROCESS_H_
#define _PROCESS_H_

#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <time.h>
#include <math.h>

#include "data_struct.h"
#include "queue.h"

void process_m(int *p1, int *p2, int *p3, int *p4);
void process_s(int *p1, int *p2, int *p3, int *p4, int f);

#endif //_PROCESS_H_