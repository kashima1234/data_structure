#ifndef _MAIN_H_
#define _MAIN_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>

#include "data_struct.h"
#include "process.h"
#include "queue.h"

#endif //_MAIN_H_